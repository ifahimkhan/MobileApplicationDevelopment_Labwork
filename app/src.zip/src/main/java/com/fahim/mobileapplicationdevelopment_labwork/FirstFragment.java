package com.fahim.mobileapplicationdevelopment_labwork;

import android.content.Context;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link FirstFragment#newInstance} factory method to
 * create an instance of this fragment.
 *
 */
public class FirstFragment extends Fragment {
    private static final String TAG = FirstFragment.class.getName();

    public static FirstFragment newInstance() {
        FirstFragment fragment = new FirstFragment();
        return fragment;
    }

    @Override
    public void onAttach(@NonNull Context context) {
        if (!requireActivity().isFinishing()){
            super.onAttach(context);
            Log.e(TAG, ":onAttach ");

        }
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Log.e(TAG, ": onCreate");

    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        Log.e(TAG, "onCreateView: ");
        return inflater.inflate(R.layout.fragment_first, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        Log.e(TAG, ":onViewCreated ");
    }

    @Override
    public void onStart() {
        super.onStart();
        Log.e(TAG, ": onStart");
    }

    @Override
    public void onResume() {
        super.onResume();
        Log.e(TAG, ": onResume");
    }

    @Override
    public void onPause() {
        super.onPause();
        Log.e(TAG, ":onPause ");
    }

    @Override
    public void onStop() {
        super.onStop();
        Log.e(TAG, ":onStop ");
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        Log.e(TAG, ": onDestroyView");
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        Log.e(TAG, ": onDestroy");
    }

    @Override
    public void onDetach() {
        super.onDetach();
        Log.e(TAG, ": onDetach");
    }

}